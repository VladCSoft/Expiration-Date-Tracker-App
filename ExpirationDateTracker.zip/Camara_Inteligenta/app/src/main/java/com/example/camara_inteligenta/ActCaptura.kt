package com.example.camara_inteligenta

import com.journeyapps.barcodescanner.CaptureActivity

class ActCaptura : CaptureActivity ()